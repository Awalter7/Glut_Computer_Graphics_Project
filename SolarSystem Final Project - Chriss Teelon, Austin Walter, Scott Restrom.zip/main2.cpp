#include <windows.h>
#include <GL\glut.h>
#include <GL\glu.h>
#include <stdio.h>
#include <iostream>
#include <cmath>
//#include "jpeg-8\jpeglib.h"
#include "readJpeg.cpp"

GLOBAL(unsigned char*) read_JPEG_file(char* filename, int& rows, int& cols);

GLubyte* image1, * image2, * image3, * image4, * image5, * image6, * sunImage;
int rows1, cols1, rows2, cols2, rows3, cols3, rows4, cols4, rows5, cols5, rows6, cols6, sunRows, sunCols;

GLubyte* backgroundImage;
int backgroundRows, backgroundCols;

GLsizei ww = 512, wh = 512;
int scale = 1;
GLfloat theta[3] = { 0, 0, 0 };
GLint axis = 0;
float x = 1.0;

float angle = 0.0f;

GLfloat cameraPos[3] = { 0.0, 0.0, 6.0 * scale };

GLfloat vertices[][3] = { {-20.0,-20.0,-20.0},{20.0,-20.0,-20.0},
{20.0,20.0,-20.0}, {-20.0,20.0,-20.0}, {-20.0,-20.0,20.0},
{20.0,-20.0,20.0}, {20.0,20.0,20.0}, {-20.0,20.0,20.0} };

// Set narrow FOV values
const float narrow_fov = 120.0f; 
const float fov_scale_factor = tan(narrow_fov * 0.5f * 3.14159265359f / 180.0f);

float scaleFactor = 1.0f;

float scaledPlanetRadii[8];

boolean zoomedIn = true;

const float planetDistances[] = { 2.0f, 3.8f, 5.0f, 7.5f, 13.0f, 23.5f, 30.0f, 39.0f };
const float planetRadii[] = { 0.017f * 0.1f, 0.044f * 0.1f, 0.046f * 0.1f, 0.025f * 0.1f, 0.5f * 0.1f, 0.42f * 0.1f, 0.18f * 0.1f, 0.17f * 0.1f };
float originalPlanetRotationSpeeds[] = { 0.1f, 0.2f, 0.3f, 0.1f, 0.5f, 0.6f, 0.7f, 0.8f };
float planetRotationSpeeds[] = { 1.0f, 0.5f, 0.3f, 0.24f, 0.1f, 0.05f, 0.03f, 0.02f };

float sunRad = 5.014 * 0.1f;



// Speed multiplier
float speedMultiplier = 1.0f;
const float minSpeedMultiplier = 0.1f;
const float maxSpeedMultiplier = 5.0f;

// Mouse input state
bool mouseDragging = false;
int mouseX = 0;

bool isPaused = false;

// Add shadow map related variables
const int shadowMapWidth = 1024;
const int shadowMapHeight = 1024;
GLuint shadowMapTexture;

// Define material properties
GLfloat material_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
GLfloat material_diffuse[] = { 0.8, 0.8, 0.8, 1.0 };
GLfloat material_specular[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat material_shininess[] = { 0.0 };
GLfloat material_emission[] = { 0.0, 0.0, 0.0, 1.0 }; // Set emission to zero for planets

// Define light properties
GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 }; // Positional light (last component is 0)
GLfloat light_ambient[] = { 0.2, 0.2, 0.2, 1.0 };
GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 }; // Set the sun light color to white
GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };

void setSpeedMultiplier(int x) {
	if (x != 1) {
		float normalizedX = static_cast<float>(x) / static_cast<float>(ww);
		speedMultiplier = minSpeedMultiplier + (maxSpeedMultiplier - minSpeedMultiplier) * normalizedX;
		for (int i = 0; i < 8; i++) {
			if (speedMultiplier < 1.0f) {
				planetRotationSpeeds[i] = originalPlanetRotationSpeeds[i] / speedMultiplier;
			}
			else {
				planetRotationSpeeds[i] = originalPlanetRotationSpeeds[i] * speedMultiplier;
			}
		}
	}
	else {
		for (int i = 0; i < 8; i++) {
			planetRotationSpeeds[i] = originalPlanetRotationSpeeds[i] * speedMultiplier;
		}
	}

}



void polygon(int a, int b, int c, int d, int cols, int rows, GLubyte * image)
{
	glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,cols,rows,0,GL_RGB,GL_UNSIGNED_BYTE, image);

	glBegin(GL_POLYGON);
		glTexCoord2f(1,0);
		glVertex3fv(vertices[a]);

		glTexCoord2f(0,0);
		glVertex3fv(vertices[b]);

		glTexCoord2f(0,1);
		glVertex3fv(vertices[c]);
 
		glTexCoord2f(1,1);
		glVertex3fv(vertices[d]);
    glEnd();
}


void cube()
{
    polygon(0,3,2,1, cols1, rows1, image1);
    polygon(2,3,7,6, cols2, rows2, image2);
    polygon(0,4,7,3, cols3, rows3, image3);
 	polygon(1,2,6,5, cols4, rows4, image4);
    polygon(4,5,6,7, cols5, rows5, image5);
    polygon(0,1,5,4, cols6, rows6, image6);
}

void animationTimer(int value) {
	glutPostRedisplay();
	glutTimerFunc(3, animationTimer, 0); // Trigger a redraw every 16 milliseconds (approx. 60 FPS)
}

enum DistanceMode {
	ORIGINAL,
	FIXED_DISTANCE
};

enum PerspectiveMode {
	ORIGINAL_PERSPECTIVE,
	TOP_DOWN_PERSPECTIVE
};

DistanceMode distanceMode = ORIGINAL;
PerspectiveMode perspectiveMode = ORIGINAL_PERSPECTIVE;


void drawPlanet(int index, GLUquadric* quad) {
	glPushMatrix();



	glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess);
	glMaterialfv(GL_FRONT, GL_EMISSION, material_emission);

	float rotationDistance = planetDistances[index];
	if (distanceMode == FIXED_DISTANCE) {
		rotationDistance = (index + 1) * .5;
	}

	switch (index) {
	case 0:
		glColor3f(0.5, 0.5, 0.5);
		break;
	case 1:
		glColor3f(0.5, 0.25, 0.0);
		break;
	case 2:
		glColor3f(0.678, 0.847, 0.902);
		break;
	case 3:
		glColor3f(1.0, 0.0, 0.0);
		break;
	case 4:
		glColor3f(0.71, 0.4, 0.11);
		break;
	case 5:
		glColor3f(1.0, 1.0, 0.0);
		break;
	case 6:
		glColor3f(0.0, 0.0, 0.5);
		break;
	case 7:
		glColor3f(0.678, 0.847, 0.902);
		break;
	}
	glRotatef(planetRotationSpeeds[index] * angle, 0.0f, 1.0f, 0.0f);
	glTranslatef(sunRad + rotationDistance, 0.0f, 0.0f);
	
	gluSphere(quad, scaledPlanetRadii[index], 32, 32);

	glPopMatrix();
}




void updateScaledPlanetRadii(float scaleFactor) {
	for (int i = 0; i < 8; i++) {
		scaledPlanetRadii[i] = planetRadii[i] * scaleFactor;
	}
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	if (perspectiveMode == ORIGINAL_PERSPECTIVE) {
		if (zoomedIn == false) {
			gluLookAt(cameraPos[0], cameraPos[1], cameraPos[2], 0, 0, 0, 0, 1, 0);
		}
		else {
			gluLookAt(cameraPos[0], cameraPos[1], cameraPos[2]+2, 0, 0, 0, 0, 1, 0);
		}
		
	}
	else if (perspectiveMode == TOP_DOWN_PERSPECTIVE) {
		if (zoomedIn == false) {
			gluLookAt(0.0f, 10.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f);
		}else {
			gluLookAt(0.0f, 10.0f, 2.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f);
		}
	}

	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	glTranslatef(0.0f, 0.0f, 0.0f);

	glPushMatrix();
	glDisable(GL_TEXTURE_2D); // Disable texture

	// First sphere (Sun)
	glTranslatef(0.0f, 0.0f, 0.0f);

	GLfloat sun_emission[] = { 1.0, 1.0, 0.8, 1.0 }; // Set sun's emission to white

	glMaterialfv(GL_FRONT, GL_EMISSION, sun_emission); // Apply white light emission to the sun
	GLUquadric* quad = gluNewQuadric();
	glColor3f(1.0f, .5f, 0.0f); // Set sphere color to yellow
	gluSphere(quad, sunRad, 32, 32);  // Create a sphere with radius 0.5 and 32 slices and stacks


	glColor3f(1.0, 1.0, 1.0);
	// Planets (Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune)
	for (int i = 0; i < 8; i++) {
		drawPlanet(i, quad);
	}
	glColor3f(1.0, 1.0, 1.0);
	gluDeleteQuadric(quad);
	glEnable(GL_TEXTURE_2D); // Enable texture
	glPopMatrix();

	
	glDisable(GL_LIGHTING);

	cube();

	glEnable(GL_LIGHTING);


	if (!isPaused) {
		// planet animation code
		angle += 0.5f;
	}

	glutSwapBuffers();
}


void reshape(int w, int h)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	float nearClip = 5 * scale;
	float farClip = 10000 * scale; // Increased far clipping plane distance

	if (w >= h)
		glFrustum(-fov_scale_factor * scale * (float)w / h, fov_scale_factor * scale * (float)w / h, -fov_scale_factor * scale, fov_scale_factor * scale, nearClip, farClip);
	else
		glFrustum(-fov_scale_factor * scale, fov_scale_factor * scale, -fov_scale_factor * scale * (float)h / w, fov_scale_factor * scale * (float)h / w, nearClip, farClip);

	glMatrixMode(GL_MODELVIEW);

	glViewport(0, 0, w, h);

	ww = w;
	wh = h;
}

void init()
{
	glEnable(GL_TEXTURE_2D);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-fov_scale_factor * scale, fov_scale_factor * scale, -fov_scale_factor * scale, fov_scale_factor * scale, 5 * scale, 15 * scale);
	glMatrixMode(GL_MODELVIEW);

	// Enable lighting

	// Set up light properties
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);

	// Set up material properties
	glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse);

	// Enable lighting
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_COLOR_MATERIAL);

	// Enable depth testing (for proper occlusion handling)
	glEnable(GL_DEPTH_TEST);

	glViewport(0, 0, ww, wh);
}

void menu(int item) {
	std::cout << item << std::endl;
	if (item <= 10) {
		setSpeedMultiplier(item);
	}
	else {
		switch (item) {
		case 11:
			std::cout << item << std::endl;
			distanceMode = ORIGINAL;
			break;
		case 12:
			std::cout << item << std::endl;
			distanceMode = FIXED_DISTANCE;
			break;
		case 13:
			std::cout << item << std::endl;
			perspectiveMode = ORIGINAL_PERSPECTIVE;
			break;
		case 14:
			std::cout << item << std::endl;
			perspectiveMode = TOP_DOWN_PERSPECTIVE;
			break;
		case 15:
			std::cout << item << std::endl;
			updateScaledPlanetRadii(1.0f);
			break;
		case 16:
			std::cout << item << std::endl;
			updateScaledPlanetRadii(5.0f);
			break;
		}
		glutPostRedisplay();
	}
}

void toggleAnimation() {
	isPaused = !isPaused;
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 'p':
		toggleAnimation();
		break;
		// rest of keyboard function
	}
}

void mouse(int button, int state, int x, int y) {
	zoomedIn = !zoomedIn;
}

void createMenu() {
	int rotation_speed_submenu_id = glutCreateMenu(menu);
	glutAddMenuEntry("1", 1);
	glutAddMenuEntry("2", 2);
	glutAddMenuEntry("3", 3);
	glutAddMenuEntry("4", 4);
	glutAddMenuEntry("5", 5);
	glutAddMenuEntry("6", 6);
	glutAddMenuEntry("7", 7);
	glutAddMenuEntry("8", 8);
	glutAddMenuEntry("9", 9);
	glutAddMenuEntry("10", 10);

	int menu_id = glutCreateMenu(menu);
	glutAddMenuEntry("Original rotation mode", 11);
	glutAddMenuEntry("Fixed distance rotation mode", 12);
	glutAddMenuEntry("Original Camera Perspective", 13);
	glutAddMenuEntry("Top-Down Perspective", 14);
	glutAddMenuEntry("Original scale", 15);
	glutAddMenuEntry("50% larger scale", 16);
	glutAddSubMenu("Change rotation speed", rotation_speed_submenu_id);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

int main(int argc, char **argv)

{

	int screenWidth = GetSystemMetrics(SM_CXSCREEN);
	int screenHeight = GetSystemMetrics(SM_CYSCREEN);

	image1 = read_JPEG_file("background24.jpg", rows1, cols1);
	image2 = read_JPEG_file("background24.jpg", rows2, cols2);
	image3 = read_JPEG_file("background24.jpg", rows3, cols3);
	image4 = read_JPEG_file("background24.jpg", rows4, cols4);
	image5 = read_JPEG_file("background24.jpg", rows5, cols5);
	image6 = read_JPEG_file("background24.jpg", rows6, cols6);


	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(screenWidth, screenHeight); // Set window size to screen dimensions
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Solar System - Austin Walter, Chris Teelon, Schott Roston ");
	init();

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutTimerFunc(0, animationTimer, 0); // Register the timer function to redraw the display



	createMenu(); // Create the dropdown menu
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);



	glutMainLoop();

	return 0;
}

